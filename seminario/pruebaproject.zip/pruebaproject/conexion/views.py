import logging

from django.http import HttpResponse

from .models import Peticionesservidor

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create your views here.
"""
Ejemplo de uso para ejecutar la peticion 507
que retorna las materias que cursa un estudiante

esta peticion solo retorna el resultado en param2 (si no ocurrio un error, 
en dicho caso param2 y param3 estaran vaicios "None")

param 2 es una lista, donde en cada posicion hay un diccionario con cada materia 
que el estudiante cursa.

"""


def index(request):
    legajo = request.GET.get("legajo")
    logging.debug(f"Received legajo: {legajo}")
    if legajo:
        try:
            peticion = Peticionesservidor()
            peticion.set_Id(legajo)
            peticion.add_parametro("legajo", legajo)
            error, param2, param3 = peticion.ejecutar_peticion(507)
            logging.debug(f"Error: {error}, Param2: {param2}, Param3: {param3}")
            if error:
                return HttpResponse(f"Error: {error}")
            return HttpResponse(f"Param2: {param2}, Param3: {param3}")
        except Exception as e:
            logging.error(f"Exception occurred: {e}")
            return HttpResponse(f"Exception occurred: {e}")
    return HttpResponse("Please provide a legajo parameter.")
